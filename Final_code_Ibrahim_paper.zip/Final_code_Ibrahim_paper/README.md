# Cox Block-VI Simulation and Real-Data Reproducibility Package

This package compares four Cox survival methods:

1. Cox-Lasso
2. Horseshoe-Cox
3. AGP-VI with stabilized block-diagonal covariance
4. Gaussian--IGH-VI with stabilized block-diagonal covariance

Run:

```r
source("run_quick_test.R")
source("run_simulation_four_methods.R")
source("run_real_data_four_methods.R")
```

Outputs are saved in `results/` and `figures/`.

Required packages:

```r
install.packages(c("survival", "glmnet", "MASS", "ggplot2", "dplyr", "tidyr", "gridExtra"))
```

Optional for Bayesian Horseshoe-Cox:

```r
install.packages("rstanarm")
```

If `rstanarm` is unavailable, the code uses a Cox-ridge approximation as a runnable fallback for the Horseshoe-Cox benchmark.
