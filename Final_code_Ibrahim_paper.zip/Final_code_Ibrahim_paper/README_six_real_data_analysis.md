# Six real-life survival datasets analysis

Run from your project root:

```r
source("R/10_real_data_analysis_six_datasets.R")
```

Required local files:
- `DBCD_Data.csv`
- `chop.csv`

Loaded package datasets:
- PBC from `survival`
- NKI70 from `penalized`
- VDX from `breastCancerVDX`
- TCGA ovarian from `curatedOvarianData`

Main outputs:
- `results/real_data/real_data_raw_results.csv`
- `results/real_data/real_data_summary_results.csv`
- `results/real_data/real_data_summary_table.tex`
- `results/real_data/time_dependent_auc_results.csv`
- `figures/real_data/time_dependent_auc_panel_1_PBC_DBCD_CHOP.png`
- `figures/real_data/time_dependent_auc_panel_1_PBC_DBCD_CHOP.pdf`
- `figures/real_data/time_dependent_auc_panel_2_NKI70_VDX_TCGA.png`
- `figures/real_data/time_dependent_auc_panel_2_NKI70_VDX_TCGA.pdf`
